This is a web-based project originally made for a friend to voice complaints online.

Missing:
-credentials.php not included, password is in plain text (for simplicity)




