<header>
	<link rel="stylesheet" type="text/css" href="css/addcomplaint.css"/>
</header>

<form action="complain.php" method="POST">
	<div>
		<label>Complaint:</label>
		<textarea name="complaint" rows="5" cols="40"></textarea>
	</div>
	<div>
		<label>Category:</label>
		<select name="category">
			<option>College</option>
			<option>Classrooms</option>			
			<option>Washroom</option>
			<option>Canteen</option>
			
			<option selected="selected">Other</option>
		</select>
	</div>
	<div>
		<label>Apne Baap ka College hai..!!:</label>
		<input type="number" name="intensity" min="1" max="10"/>
	</div>
	<div>
		<label>Password:</label>
		<input type="password" name="password"/>
	</div>
	<div>
		<input type="submit" value="Submit"/>
	</div>
</form>
<p>
	<a href="./">
		Home
	</a>
</p>
<p>
	<a href="./viewcomplaints.php">
		View complaints
	</a>
</p>
